from driving_env import MultiRotorEnv

from stable_baselines.sac.policies import LnMlpPolicy
from stable_baselines import SAC, HER
from stable_baselines.common.callbacks import CheckpointCallback
from stable_baselines.common.buffers import ReplayBuffer

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

if __name__ == '__main__':
    save_name = 'train_model_1025'
    random_seed = 100
    #model_class = SAC  # works also with SAC, DDPG and TD3
    env = MultiRotorEnv(drone_id="Drone1", speed=1.0, ip='127.0.0.1', port=8000, seed=random_seed)
    # Available strategies: future, final, episode, random
    #goal_selection_strategy = 'final' # equivalent to GoalSelectionStrategy.FUTURE
    #n_sampled_subgoal = 4

    model = SAC(
        'LnMlpPolicy',
        env,
        #model_class,
        #n_sampled_subgoal,
        #goal_selection_strategy,
        verbose=1,
        buffer_size=500000,
        learning_rate=0.0003,
        batch_size=512,
        gamma=0.99,
        tau=0.005,
        ent_coef='auto',
        target_entropy='auto',
        train_freq=1,
        gradient_steps=1,
        learning_starts=50000, 
        tensorboard_log="./pwmgps_log/"
    )
    
    for _ in range(100):
        obs = env.reset()
        done = False
        while not done:
            action, _ = model.predict(obs)
            next_obs, reward, done, info = env.step(action)
            action = info['new_action']
            #print(f'action = {action}, next_obs = {next_obs}')
            model.replay_buffer.add(obs, action, reward, next_obs, done)
            obs = next_obs
    
    #load_name = 'train_model_noaction/rl_model_1000000_steps'
    #model = SAC.load(load_name)
    #model.set_env(env)

    env.init_distortion(0)
    callback = CheckpointCallback(save_freq=50000, save_path=save_name)
    model.learn(total_timesteps=2000000, callback=callback, log_interval=10, tb_log_name="SAC_256")
    model.save(save_name)