from stable_baselines.common.policies import MlpPolicy
from stable_baselines.sac.policies import LnMlpPolicy
from stable_baselines.common.vec_env import SubprocVecEnv

from driving_env import MultiRotorEnv
from stable_baselines import SAC
from stable_baselines.common.callbacks import CheckpointCallback
#from stable_baselines3.common.vec_env import SubprocVecEnv
#from stable_baselines3.common.vec_env import DummyVecEnv
#from stable_baselines3.common.vec_env import VecFrameStack
from stable_baselines.common.buffers import ReplayBuffer
import math
import os
import numpy as np
from numpy.linalg import norm
import json
import pandas as pd

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import matplotlib.pyplot as plt


def plotting(x, y, str):
    plt.clf()
    plt.plot(x, y)
    plt.xlabel('distortion rate')
    plt.ylabel(str)
    plt.title(str + " Graph")
    plt.grid(True)

    plt.savefig(str + ' graph.png')
    plt.show()


if __name__ == '__main__':

    save_name = 'train_model_noaction/rl_model_1000000_steps.zip'
    random_seed = 100


    env = MultiRotorEnv(drone_id="Drone1", speed=1.0, ip='127.0.0.1', port=8000, seed=random_seed)
    '''
    model = SAC(
        'LnMlpPolicy',
        env,
        verbose=1,
        buffer_size=1000000,
        learning_rate=0.0003,
        batch_size=512,
        gamma=0.95,
        tau=0.005,
        ent_coef='auto',
        target_entropy='auto',
        train_freq=1,
        gradient_steps=1, 
        learning_starts=100
    )'''
    model = SAC.load(save_name)

    print(save_name)
    
    distance_dict = {}
    distance_dict[5] = {}
    distance_dict[10] = {}

    for dist_val in [5,10]:
        env.sijak = dist_val #시작위치 설정

        distance_per_distortion = []
        dist_rate = []

        for distortion in range(13):
            env.init_distortion(distortion * 10)
            dist_rate.append(distortion * 10)
            distance = []
            print(f'\ndistortion = {distortion * 10}')

            distance_dict[distortion * 10] = None
            for epoch in range(10):
                temp = []
                obs = env.reset()
                dones = False
                ep_reward = 0
                for i in range(1000):
                    if dones:
                        break
                    action, _states = model.predict(obs, deterministic=True)
                    obs, rewards, dones, info = env.step(action)
                    ep_reward += rewards
                    temp.append(norm(info['distance'],2))
                print("ep_reward", ep_reward, epoch)
                if len(temp) >= 100:
                    print(f'100스텝 평균 : {sum(temp[-100:]) / len(temp[-100:])}')
                    distance.append(round(sum(temp[-100:]) / len(temp[-100:]), 2))
                else :
                    print(f'{len(temp)}스텝 평균 : {sum(temp) / len(temp)}')
                    distance.append(round(sum(temp) / len(temp),2))

            distance_dict[dist_val][distortion*10] = distance
            distance_per_distortion.append(sum(distance) / len(distance))
        
        plotting(dist_rate, distance_per_distortion, 'last 100 steps mean distance '+str(dist_val)+'m random start')

    df = pd.DataFrame(distance_dict[5])
    df.to_csv('5_dist.csv')
    df2 = pd.DataFrame(distance_dict[10])
    df2.to_csv('10_dist.csv')

    


