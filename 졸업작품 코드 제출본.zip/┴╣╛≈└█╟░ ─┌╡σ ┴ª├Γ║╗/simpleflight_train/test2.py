from stable_baselines.common.policies import MlpPolicy
from stable_baselines.sac.policies import LnMlpPolicy
from stable_baselines.common.vec_env import SubprocVecEnv

from driving_env import MultiRotorEnv
from stable_baselines import SAC
from stable_baselines.common.callbacks import CheckpointCallback
#from stable_baselines3.common.vec_env import SubprocVecEnv
#from stable_baselines3.common.vec_env import DummyVecEnv
#from stable_baselines3.common.vec_env import VecFrameStack
from stable_baselines.common.buffers import ReplayBuffer
import math
import os
import numpy as np
from numpy.linalg import norm

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import matplotlib.pyplot as plt

def plotting(x, y, str):
    plt.clf()
    plt.plot(x, y)
    plt.xlabel('steps')
    plt.ylabel(str)
    plt.title(str + " Graph")
    plt.grid(True)

    plt.savefig(str + ' graph.png')
    plt.show()


if __name__ == '__main__':

    save_name = 'train_model_noaction/rl_model_1000000_steps.zip'
    random_seed = 100


    env = MultiRotorEnv(drone_id="Drone1", speed=1.0, ip='127.0.0.1', port=8000, seed=random_seed)
    '''
    model = SAC(
        'LnMlpPolicy',
        env,
        verbose=1,
        buffer_size=1000000,
        learning_rate=0.0003,
        batch_size=512,
        gamma=0.95,
        tau=0.005,
        ent_coef='auto',
        target_entropy='auto',
        train_freq=1,
        gradient_steps=1, 
        learning_starts=100
    )'''
    model = SAC.load(save_name)

    print(save_name)
    #distance_per_distortion = []
    #dist_rate = []

    distortion = 50
    
    env.init_distortion(distortion)
    distance = []
    print(f'distortion = {distortion}')
    for epoch in range(1):
        temp = []
        steps = []
        ang_vels = []

        obs = env.reset()
        dones = False
        ep_reward = 0
        for i in range(1000):
            if dones:
                break
            steps.append(i)
            action, _states = model.predict(obs, deterministic=True)
            obs, rewards, dones, info = env.step(action)
            ep_reward += rewards
            temp.append(norm(info['distance'],2))
            ang_vels.append(round(info['ang_vel'][0],2))
        print("ep_reward", ep_reward, epoch)

        if len(temp) >= 100:
            print(f'100스텝 평균 : {sum(temp[-100:]) / len(temp[-100:])}')
            distance.append(sum(temp[-100:]) / len(temp[-100:]))
        else :
            print(f'{len(temp)}스텝 평균 : {sum(temp) / len(temp)}')
            distance.append(sum(temp) / len(temp))

        plotting(steps, ang_vels, 'ang_vels_dist10')

    print(f'\ndistance = {distance}')
    print(f'시작 거리 10 mean dist = {sum(distance) / len(distance)}')

    
    #distance_per_distortion.append(sum(distance) / len(distance))
    
    #plotting(dist_rate, distance_per_distortion, 'last 100 steps mean distance')


