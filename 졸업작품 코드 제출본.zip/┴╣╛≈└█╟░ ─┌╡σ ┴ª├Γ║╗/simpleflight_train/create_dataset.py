from driving_env import MultiRotorEnv

from stable_baselines.sac.policies import LnMlpPolicy
from stable_baselines import SAC
from stable_baselines.common.callbacks import CheckpointCallback
from stable_baselines.common.buffers import ReplayBuffer

import json
import pickle

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import matplotlib.pyplot as plt

def plotting(x, y, str):
    plt.clf()
    plt.plot(x, y)
    plt.xlabel('Distortion rate')
    plt.ylabel(str)
    plt.title(str + " Graph")
    plt.grid(True)

    plt.savefig(str + ' graph.png')
    plt.show()


if __name__ == '__main__':
    
    save_name = 'train_model_obsil/rl_model_550000_steps.zip'
    random_seed = 100

    env = MultiRotorEnv(drone_id="Drone1", speed=2.7, ip='127.0.0.1', port=8000)
    # policy_kwargs = dict(net_arch=[300, 300, 300])
    model = SAC(
        'LnMlpPolicy',
        env,
        # policy_kwargs=policy_kwargs,
        verbose=1,
        buffer_size=500000,
        learning_rate=0.0003,
        batch_size=512,
        gamma=0.99,
        tau=0.005,
        ent_coef='auto',
        target_entropy='auto',
        train_freq=1,
        gradient_steps=1,
        learning_starts=1000,
        tensorboard_log="runs/"
    )
    
    model = SAC.load(save_name)
    print(save_name)

    setting_path = "/home/tako/Documents/Airsim/airsim_settings/settings1.json"
    datasets = {}
    
    stack_num = 10
    step_per_dist = 50000

    for i in range(0, 9):
        datasets[str(i * 10)] = []
        
        with open(setting_path, 'r') as f:
            airsim_setting = json.load(f)
            
        dist_per = i * 10

        airsim_setting["Vehicles"]["Drone1"]["Sensors"]["imu"]["AngularRandomWalk"] = 0.3 + 32 * i
        airsim_setting["Vehicles"]["Drone1"]["Sensors"]["imu"]["VelocityRandomWalk"] = 0.24 + 3.2 * i
        
        with open(setting_path, 'w') as f:
            json.dump(airsim_setting, f, indent=4)
            
        time_step = 0
        
        while time_step < step_per_dist:
            obss = []
            obs = env.reset()
            obss.append(obs)
            done = False
            while not done and time_step < step_per_dist:
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, done, info = env.step(action)
                obss.append(obs)
                time_step += 1
                
            for obs in obss:
                datasets[str(i * 10)].append(obs.tolist())
                
        print("-" * 100)      
        print(str(dist_per) + " done!")
        print("-" * 100)

    dataset_path = "./sl_dataset/obsil_Data.pkl"

    with open(dataset_path, 'wb') as f:
        pickle.dump(datasets, f)
        
    ### 여기가 끝 ###
    
    with open(setting_path, 'r') as f:
        airsim_setting = json.load(f)
        
    airsim_setting["Vehicles"]["Drone1"]["Sensors"]["imu"]["AngularRandomWalk"] = 0.3
    airsim_setting["Vehicles"]["Drone1"]["Sensors"]["imu"]["VelocityRandomWalk"] = 0.24
    
    with open(setting_path, 'w') as f:
        json.dump(airsim_setting, f, indent=4)
                
            